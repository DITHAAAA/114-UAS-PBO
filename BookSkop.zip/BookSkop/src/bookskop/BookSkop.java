package bookskop;

public class BookSkop {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
